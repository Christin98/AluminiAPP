/******************************************************************************
 * Copyright (c) 2020.                                                        *
 * Christin B Koshy.                                                          *
 * 29                                                                         *
 ******************************************************************************/

package com.project.major.alumniapp.models;

public interface UtilityInterface {
    void loadMore(long limit);
}
