
package com.project.major.alumniapp.models

interface UtilityInterface {
    fun loadMore(limit: Long)
}