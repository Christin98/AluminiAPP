package com.project.major.alumniapp.utils

import android.content.Context
import id.zelory.compressor.Compressor
import java.io.File
import java.io.IOException

class FileCompressor(private val context: Context) {
    fun compressImage(imageUrl: String): File {
        val imageFile = File(imageUrl)
        return try {
            Compressor(context).compressToFile(imageFile)
        } catch (e: IOException) {
            e.printStackTrace()
            File(imageUrl)
        }
    }

}