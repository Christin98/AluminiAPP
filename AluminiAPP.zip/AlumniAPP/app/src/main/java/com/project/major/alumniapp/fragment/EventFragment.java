package com.project.major.alumniapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.project.major.alumniapp.R;
import com.project.major.alumniapp.activities.AddEvent;
import com.project.major.alumniapp.activities.CommentsActivity;
import com.project.major.alumniapp.models.Event;
import com.project.major.alumniapp.models.NotificationModel;
import com.project.major.alumniapp.models.User;
import com.project.major.alumniapp.utils.FcmNotification;
import com.project.major.alumniapp.utils.HeartAnimation;
import com.project.major.alumniapp.utils.LoadingDialog;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;


public class EventFragment extends Fragment {

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private Button addEvent;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private FirebaseRecyclerAdapter adapter;
    private FirebaseAuth mAuth;
    private String profileImgUrl = "";
    private HeartAnimation heartAnimation;
    private boolean mLikedByCurrentUser = false;
    private String likeId;
    private String mLikesString;
    //    private FirebaseMethods firebaseMethods;
    private StringBuilder mStringBuilder;
    private LoadingDialog loadingDialog;
    TextView textView;
//    private Photo photo;
//    private Video video;

    public EventFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_event, container, false);

        mAuth = FirebaseAuth.getInstance();
        addEvent = view.findViewById(R.id.addEvent);
        addEvent.setVisibility(View.INVISIBLE);
        recyclerView = view.findViewById(R.id.event_recyclerView);
        textView = view.findViewById(R.id.textView4);
        linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        loadingDialog = new LoadingDialog(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);
        heartAnimation = new HeartAnimation();
        loadingDialog.showLoading();
        fetch();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("alumni_app").child("Events");
        databaseReference.keepSynced(true);

        addEvent.setOnClickListener(v -> startActivity(new Intent(getContext(), AddEvent.class)));

        firebaseDatabase.getReference("alumni_app").child("users").child(mAuth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String user_type = dataSnapshot.child("user_type").getValue(String.class);
                if (user_type.equals("admin") || user_type.equals("super_admin")) {
                    addEvent.setVisibility(View.VISIBLE);
                } else {
                    addEvent.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return view;
    }

    private void fetch() {

        Query query = FirebaseDatabase.getInstance().getReference("alumni_app").child("Events");

        FirebaseRecyclerOptions<Event> options = new FirebaseRecyclerOptions.Builder<Event>().setQuery(query, Event.class).build();

        adapter = new FirebaseRecyclerAdapter<Event, ViewHolder>(options) {
            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.event_item, parent, false);

                return new ViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Event event) {
                loadingDialog.hideLoading();
                textView.setVisibility(View.GONE);
                String post_key = getRef(position).getKey();
                holder.title.setText(event.getName());
                holder.desc.setText(event.getDesc());
                holder.name.setText(event.getEmail());
                setLikeListeners(holder.heartOutline, holder.heartRed, post_key, holder.likedBy);
                setUserLikes(holder.heartOutline, holder.heartRed, post_key, holder.likedBy);
                launchComment(post_key, holder);
                CharSequence timeAgo = DateUtils.getRelativeTimeSpanString(Long.parseLong(event.getDate_added()), System.currentTimeMillis(), DateUtils.SECOND_IN_MILLIS);
                holder.dateadded.setText(timeAgo);
                if (event.getUrl() != null) {
                    Glide.with(getContext())
                            .load(event.getUrl())
                            .apply(new RequestOptions().override(300, 300)
                                    .placeholder(R.drawable.postimg)
                                    .error(R.drawable.error_img)
                                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE))
                            .into(holder.postimg);
//                    Picasso.get()
//                            .load(event.geturl())
//                            .networkPolicy(NetworkPolicy.OFFLINE)
//                            .resize(300, 300)
//                            .placeholder(R.drawable.postimg)
//                            .error(R.drawable.postimg)
//                            .into(holder.postimg);
                    holder.postimg.setVisibility(View.VISIBLE);
                    holder.progressBar.setVisibility(View.GONE);
                } else {
                    holder.postimg.setVisibility(View.GONE);
                    holder.progressBar.setVisibility(View.GONE);
                }
            }
        };
        if(adapter.getItemCount() != 0){
            textView.setVisibility(View.GONE);
        } else {
            textView.setVisibility(View.VISIBLE);
            loadingDialog.hideLoading();
        }
        recyclerView.scrollToPosition(adapter.getItemCount() - 1);
        recyclerView.setAdapter(adapter);
    }

    private void launchComment(String mediaId, ViewHolder view) {

        ImageView comment = view.comment;
        TextView viewComments = view.viewComments;
        final Intent mediaIntent = new Intent(getContext(), CommentsActivity.class);
        mediaIntent.putExtra("mediaID", mediaId);
        mediaIntent.putExtra("profile_photo", profileImgUrl);
        mediaIntent.putExtra("node", "Events");

        final View.OnClickListener onClickListener = v -> getContext().startActivity(mediaIntent);
        viewComments.setOnClickListener(onClickListener);

        comment.setOnClickListener(onClickListener);
    }

    private void setLikeListeners(final ImageView heartOutline, final ImageView heartRed, String key, final TextView likedBy) {

        final View.OnClickListener onClickListener = v -> toggleLike(heartOutline, heartRed, key, likedBy);
        heartOutline.setOnClickListener(onClickListener);
        heartRed.setOnClickListener(onClickListener);
    }

    private void toggleLike(final ImageView heartOutline, final ImageView heartRed, String key, final TextView likedBy) {

        mLikedByCurrentUser = false;
        Query query = FirebaseDatabase.getInstance().getReference().child("alumni_app").child("Events").child(key).child("likes");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (!dataSnapshot.exists()) {
                    mLikesString = "";
                    mLikedByCurrentUser = false;
                    heartRed.setVisibility(View.GONE);
                    heartOutline.setVisibility(View.VISIBLE);
                } else {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {

                        if (Objects.requireNonNull(ds.child("user_id").getValue()).equals(Objects.requireNonNull(mAuth.getCurrentUser()).getUid())) {
                            mLikedByCurrentUser = true;
                            likeId = ds.getKey();
                            Log.d("TAG", "LikeID = " + likedBy);
                            heartOutline.setVisibility(View.GONE);
                            heartRed.setVisibility(View.VISIBLE);
                            heartAnimation.toggleLike(heartOutline, heartRed);
//                            removeNewLike( key, likeId);
                            removeNewLike(key, likeId);
                            setUserLikes(heartOutline, heartRed, key, likedBy);
                        }
                    }
                }

                if (!mLikedByCurrentUser) {
                    Log.d("TAG", "Datasnapshot doesn't exists");
                    heartOutline.setVisibility(View.VISIBLE);
                    heartRed.setVisibility(View.GONE);
                    heartAnimation.toggleLike(heartOutline, heartRed);
                    addNewLike(key);
                    setUserLikes(heartOutline, heartRed, key, likedBy);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }

    private void setUserLikes(final ImageView heartOutline, final ImageView heartRed, String mediaId, final TextView likedBy) {

        Query query = databaseReference.child(mediaId)
                .child("likes");

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (!dataSnapshot.exists()) {
                    heartOutline.setVisibility(View.VISIBLE);
                    heartRed.setVisibility(View.GONE);
                    likedBy.setText("");
                } else {
                    heartRed.setVisibility(View.GONE);
                    heartOutline.setVisibility(View.VISIBLE);
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        if (ds.child("user_id").getValue().equals(Objects.requireNonNull(mAuth.getCurrentUser()).getUid())) {
                            heartOutline.setVisibility(View.GONE);
                            heartRed.setVisibility(View.VISIBLE);
                        }
                        setLikeText(ds, likedBy);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }


    private void setLikeText(DataSnapshot dataSnapshot, final TextView likedBy) {

        mStringBuilder = new StringBuilder();
        Query query = FirebaseDatabase.getInstance().getReference("alumni_app").child("users").orderByChild("uid")
                .equalTo(dataSnapshot.child("user_id").getValue().toString());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mStringBuilder.append(Objects.requireNonNull(dataSnapshot.getChildren().iterator().next().getValue(User.class)).getUser_name());
                mStringBuilder.append(",");
//

                String[] splitUsers = mStringBuilder.toString().split(",");

                int length = splitUsers.length;
                if (length == 1) {
                    mLikesString = "Liked by " + splitUsers[0];
                } else if (length == 2) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + " and " + splitUsers[1];
                } else if (length == 3) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + ", " + splitUsers[1]
                            + " and " + splitUsers[2];

                } else if (length == 4) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + ", " + splitUsers[1]
                            + ", " + splitUsers[2]
                            + " and " + splitUsers[3];
                } else if (length > 4) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + ", " + splitUsers[1]
                            + ", " + splitUsers[2]
                            + " and " + (dataSnapshot.getChildrenCount() - 3) + " others";
                }
                likedBy.setText(mLikesString);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void addNewLike(String mediaId) {

        String likesId = firebaseDatabase.getReference().push().getKey();
        databaseReference.child(mediaId).child("likes").child(likesId).child("user_id").setValue(mAuth.getCurrentUser().getUid());
        new FcmNotification(getContext()).sendNotification(getContext(), databaseReference, mediaId, likesId, false);
        databaseReference.child(mediaId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String uid = dataSnapshot.child("user_id").getValue(String.class);
                NotificationModel notificationModel = (mAuth.getCurrentUser().getUid().equals(uid))?new NotificationModel("like", "You", Long.toString(System.currentTimeMillis()),uid):new NotificationModel("like", mAuth.getCurrentUser().getDisplayName(), Long.toString(System.currentTimeMillis()),uid);
                FirebaseDatabase.getInstance().getReference("alumni_app").child("notification").child(uid).child(likesId).setValue(notificationModel);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void removeNewLike(String mediaId, String likesId) {

        databaseReference.child(mediaId).child("likes").child(likesId).removeValue();
        databaseReference.child(mediaId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String uid = dataSnapshot.child("user_id").getValue(String.class);
                FirebaseDatabase.getInstance().getReference("alumni_app").child("notification").child(uid).child(likesId).removeValue();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView title, desc, name, dateadded;
        TextView likedBy;
        ImageView postimg;
        ImageView heartOutline;
        ImageView heartRed;
        CircleImageView circleImageView;
        ImageView comment;
        TextView viewComments;
        ProgressBar progressBar;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.event_name);
            desc = itemView.findViewById(R.id.caption_text);
            name = itemView.findViewById(R.id.user_name);
            dateadded = itemView.findViewById(R.id.date_added);
            likedBy = itemView.findViewById(R.id.like_number);
            postimg = itemView.findViewById(R.id.media_post);
            heartOutline = itemView.findViewById(R.id.heart_outline);
            heartRed = itemView.findViewById(R.id.heart_red);
            circleImageView = itemView.findViewById(R.id.profile_photo);
            comment = itemView.findViewById(R.id.comment);
            viewComments = itemView.findViewById(R.id.view_comments);
            progressBar = itemView.findViewById(R.id.progressBar);
        }
    }
}
