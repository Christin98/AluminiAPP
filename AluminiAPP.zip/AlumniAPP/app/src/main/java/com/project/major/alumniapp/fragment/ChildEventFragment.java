package com.project.major.alumniapp.fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.project.major.alumniapp.R;
import com.project.major.alumniapp.models.UploadEvent;
import com.sdsmdg.tastytoast.TastyToast;

import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;


public class ChildEventFragment extends Fragment {

    private static final int PICK_FROM_CAMERA = 1;
    private static final int PICK_FROM_GALLARY = 2;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    private DatabaseReference mDatabase;
    StorageReference eventrefrance;
    Uri uri;
    EditText event_name, desc, loc;
    Button uploadEvent;
    CircleImageView profile_image;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_child_event, container, false);

        mDatabase = FirebaseDatabase.getInstance().getReference("alumni_app").getRef();
        eventrefrance = FirebaseStorage.getInstance().getReference("eventpics");
        profile_image= view.findViewById(R.id.profile_image);
        uploadEvent = view.findViewById(R.id.uploadEvent);
        event_name = view.findViewById(R.id.event_name);
        desc = view.findViewById(R.id.event_details);
        loc = view.findViewById(R.id.event_location);

        profile_image.setOnClickListener(v -> pickIMage());

        uploadEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uri != null){
                    upload(uri);
                } else {
                    upload();
                }
            }
        });

        return view;
    }

    void pickIMage()
    {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityForResult(Intent.createChooser(intent,"Select Image"),1002);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==1002){
            try {
                uri=data.getData();
                Bitmap bm= MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(),data.getData());
                profile_image.setImageBitmap(bm);
            } catch (IOException e) {
                e.printStackTrace();
                TastyToast.makeText(getActivity(), ""+e, TastyToast.LENGTH_SHORT, TastyToast.ERROR).show();
            }
        }
        //the end  onActivityResult
    }

    public void upload(Uri uri)
    {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        final String email = user.getEmail();
        final String eventName = event_name.getText().toString();
        final String description = desc.getText().toString();
        final String location = loc.getText().toString();
        final String id = mDatabase.push().getKey();
        final ProgressDialog progressDialog=new ProgressDialog(getActivity());
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Uploading....");
        progressDialog.show();
        UploadTask uploadTask;
        StorageMetadata metadata = new StorageMetadata.Builder().setContentType("image/jpeg").build();
        uploadTask = eventrefrance.child("alumniapp_"+id).putFile(uri,metadata);

        uploadTask.addOnSuccessListener(taskSnapshot -> {
            String url=taskSnapshot.getMetadata().getReference().getDownloadUrl().toString();
            final UploadEvent uploadPost = new UploadEvent(id, eventName, description, location, email, url);
            mDatabase.child("Events").child(id).setValue(uploadPost).addOnSuccessListener(aVoid -> {
                progressDialog.dismiss();
                TastyToast.makeText(getActivity(), "Post Added ", TastyToast.LENGTH_SHORT, TastyToast.SUCCESS).show();
            });



        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
            TastyToast.makeText(getActivity(), "failed", TastyToast.LENGTH_SHORT, TastyToast.ERROR).show();
        });
    }

    public void upload(){
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        final String email = user.getEmail();
        final String eventName = event_name.getText().toString();
        final String description = desc.getText().toString();
        final String location = loc.getText().toString();
        final String id = mDatabase.push().getKey();
        final ProgressDialog progressDialog=new ProgressDialog(getActivity());
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Adding Event ....");
        progressDialog.show();

        final UploadEvent uploadPost = new UploadEvent(id, eventName, description, location, email);
        mDatabase.child("Posts").child(id).setValue(uploadPost).addOnSuccessListener(aVoid -> {
            progressDialog.dismiss();
            TastyToast.makeText(getActivity(), "Event Added ", TastyToast.LENGTH_SHORT, TastyToast.SUCCESS).show();
        });
    }


}
