package com.project.major.alumniapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.project.major.alumniapp.R;
import com.project.major.alumniapp.activities.AddFeeds;
import com.project.major.alumniapp.activities.CommentsActivity;
import com.project.major.alumniapp.models.Feeds;
import com.project.major.alumniapp.models.NotificationModel;
import com.project.major.alumniapp.models.User;
import com.project.major.alumniapp.utils.FcmNotification;
import com.project.major.alumniapp.utils.HeartAnimation;
import com.project.major.alumniapp.utils.LoadingDialog;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class FeedsFragment extends Fragment {

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private Button addEvent;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private FirebaseRecyclerAdapter adapter;
    private FirebaseAuth mAuth;
    private String profileImgUrl = "";
    private HeartAnimation heartAnimation;
    private boolean mLikedByCurrentUser = false;
    private String likeId;
    private String mLikesString;
    private StringBuilder mStringBuilder;
    private LoadingDialog loadingDialog;
    TextView textView;


    public FeedsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_feeds, container, false);
        mAuth = FirebaseAuth.getInstance();
        addEvent = view.findViewById(R.id.addFeed);
        recyclerView = view.findViewById(R.id.feed_recyclerView);
        textView = view.findViewById(R.id.textView4);
        loadingDialog = new LoadingDialog(getActivity());
        linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        loadingDialog.showLoading();
        recyclerView.setLayoutManager(linearLayoutManager);
        heartAnimation = new HeartAnimation();
        recyclerView.setHasFixedSize(true);
        fetch();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("alumni_app").child("Feeds");
        databaseReference.keepSynced(true);

        addEvent.setOnClickListener(v -> startActivity(new Intent(getContext(), AddFeeds.class)));

        return view;
    }

    private void fetch() {
        Query query = FirebaseDatabase.getInstance().getReference("alumni_app").child("Feeds");

        FirebaseRecyclerOptions<Feeds> options = new FirebaseRecyclerOptions.Builder<Feeds>().setQuery(query, Feeds.class).build();

        adapter = new FirebaseRecyclerAdapter<Feeds, FeedsFragment.ViewHolder>(options) {

            @NonNull
            @Override
            public FeedsFragment.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.feed_item, parent, false);

                return new ViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull FeedsFragment.ViewHolder holder, int position, @NonNull Feeds feeds) {
                loadingDialog.hideLoading();
                textView.setVisibility(View.GONE);
                String post_key = getRef(position).getKey();
                holder.name.setText(feeds.getName());

                Log.d("FEEDS ", feeds.getCaption_text());
                setLikeListeners(holder.heartOutline, holder.heartRed, post_key, holder.likedBy);
                setUserLikes(holder.heartOutline, holder.heartRed, post_key, holder.likedBy);
                launchComment(post_key, holder);

                CharSequence timeAgo = DateUtils.getRelativeTimeSpanString(Long.parseLong(feeds.getTimestamp()), System.currentTimeMillis(), DateUtils.SECOND_IN_MILLIS);
                holder.timestamp.setText(timeAgo);

                if (!TextUtils.isEmpty(feeds.getCaption_text())) {
                    holder.caption.setText(feeds.getCaption_text());
                    holder.caption.setVisibility(View.VISIBLE);
                } else {
                    holder.caption.setVisibility(View.GONE);
                }

                if (feeds.getText_url() != null) {
                    holder.textUrl.setText(Html.fromHtml("<a href=\"" + feeds.getText_url() + "\">" + feeds.getText_url() + "</a>"));
                    holder.textUrl.setMovementMethod(LinkMovementMethod.getInstance());
                    holder.textUrl.setVisibility(View.VISIBLE);
                } else {
                    holder.textUrl.setVisibility(View.GONE);
                }

                if (feeds.getFeed_image_url() != null) {
                    Log.d("FEEDS ", feeds.getFeed_image_url());
//                    Picasso.get()
//                            .load(feeds.getFeed_image_url())
//                            .networkPolicy(NetworkPolicy.OFFLINE)
//                            .resize(300, 300)
//                            .placeholder(R.drawable.postimg)
//                            .error(R.drawable.error_img)
//                            .into(holder.feedImage);
                    Glide.with(getContext())
                            .load(feeds.getFeed_image_url())
                            .apply(new RequestOptions().override(300, 300).centerCrop()
                                    .placeholder(R.drawable.postimg).diskCacheStrategy(DiskCacheStrategy.ALL)
                                    .error(R.drawable.error_img))
                            .into(holder.feedImage);
                    holder.feedImage.setVisibility(View.VISIBLE);
                } else {
                    holder.feedImage.setVisibility(View.GONE);
                }
            }
        };
        if(adapter.getItemCount() != 0){
            textView.setVisibility(View.GONE);
        } else {
            textView.setVisibility(View.VISIBLE);
            loadingDialog.hideLoading();
        }
        recyclerView.scrollToPosition(adapter.getItemCount() -1);
        recyclerView.setAdapter(adapter);
    }

    private void launchComment(String mediaId, ViewHolder view) {

        ImageView comment = view.comment;
        TextView viewComments = view.viewComments;
        final Intent mediaIntent = new Intent(getContext(), CommentsActivity.class);
        mediaIntent.putExtra("mediaID", mediaId);
        mediaIntent.putExtra("profile_photo", profileImgUrl);
        mediaIntent.putExtra("node", "Feeds");

        final View.OnClickListener onClickListener = v -> getContext().startActivity(mediaIntent);
        viewComments.setOnClickListener(onClickListener);

        comment.setOnClickListener(onClickListener);
    }

    private void setLikeListeners(final ImageView heartOutline, final ImageView heartRed, String key, final TextView likedBy) {

        final View.OnClickListener onClickListener = v -> toggleLike(heartOutline, heartRed, key, likedBy);
        heartOutline.setOnClickListener(onClickListener);
        heartRed.setOnClickListener(onClickListener);
    }

    private void toggleLike(final ImageView heartOutline, final ImageView heartRed, String key, final TextView likedBy) {

        mLikedByCurrentUser = false;
        Query query = FirebaseDatabase.getInstance().getReference().child("alumni_app").child("Feeds").child(key).child("likes");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (!dataSnapshot.exists()) {
                    mLikesString = "";
                    mLikedByCurrentUser = false;
                    heartRed.setVisibility(View.VISIBLE);
                    heartOutline.setVisibility(View.GONE);
//                    addNewLike(key);
//                    setUserLikes(heartOutline, heartRed, key ,likedBy);
                } else {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {

                        if (Objects.requireNonNull(ds.child("user_id").getValue()).equals(Objects.requireNonNull(mAuth.getCurrentUser()).getUid())) {
                            mLikedByCurrentUser = true;
                            likeId = ds.getKey();
                            Log.d("TAG", "LikeID = " + likedBy);
                            heartOutline.setVisibility(View.VISIBLE);
                            heartRed.setVisibility(View.GONE);
                            heartAnimation.toggleLike(heartOutline, heartRed);
                            removeNewLike(key, likeId);
                            setUserLikes(heartOutline, heartRed, key, likedBy);
                        }
                    }
                }
//
                if (!mLikedByCurrentUser) {
                    Log.d("TAG", "Datasnapshot doesn't exists");
                    heartOutline.setVisibility(View.VISIBLE);
                    heartRed.setVisibility(View.GONE);
                    heartAnimation.toggleLike(heartOutline, heartRed);
                    addNewLike(key);
                    setUserLikes(heartOutline, heartRed, key, likedBy);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }

    private void setUserLikes(final ImageView heartOutline, final ImageView heartRed, String mediaId, final TextView likedBy) {

        Query query = databaseReference.child(mediaId)
                .child("likes");

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (!dataSnapshot.exists()) {
                    heartOutline.setVisibility(View.VISIBLE);
                    heartRed.setVisibility(View.GONE);
                    likedBy.setText("");
//                    Toast.makeText(getContext(), "set user likes not exists", Toast.LENGTH_SHORT).show();
                } else {
                    heartRed.setVisibility(View.GONE);
                    heartOutline.setVisibility(View.VISIBLE);
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {

                        if (ds.child("user_id").getValue().equals(Objects.requireNonNull(mAuth.getCurrentUser()).getUid())) {
                            heartOutline.setVisibility(View.GONE);
                            heartRed.setVisibility(View.VISIBLE);
                        }
                        setLikeText(ds, likedBy);
                    }
//                    Toast.makeText(getContext(), "set user likes exists", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void setLikeText(DataSnapshot dataSnapshot, final TextView likedBy) {

        mStringBuilder = new StringBuilder();
        Query query = FirebaseDatabase.getInstance().getReference("alumni_app").child("users").orderByChild("uid")
                .equalTo(dataSnapshot.child("user_id").getValue().toString());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnaps) {
                mStringBuilder.append(Objects.requireNonNull(dataSnaps.getChildren().iterator().next().getValue(User.class)).getUser_name());
                mStringBuilder.append(",");

                String[] splitUsers = mStringBuilder.toString().split(",");

                int length = splitUsers.length;
                if (length == 1) {
                    mLikesString = "Liked by " + splitUsers[0];
                } else if (length == 2) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + " and " + splitUsers[1];
                } else if (length == 3) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + ", " + splitUsers[1]
                            + " and " + splitUsers[2];

                } else if (length == 4) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + ", " + splitUsers[1]
                            + ", " + splitUsers[2]
                            + " and " + splitUsers[3];
                } else if (length > 4) {
                    mLikesString = "Liked by " + splitUsers[0]
                            + ", " + splitUsers[1]
                            + ", " + splitUsers[2]
                            + " and " + (dataSnapshot.getChildrenCount() - 3) + " others";
                }
                likedBy.setText(mLikesString);
//                mStringBuilder = new StringBuilder();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void addNewLike(String mediaId) {
        String likesId = firebaseDatabase.getReference().push().getKey();
        databaseReference.child(mediaId).child("likes").child(likesId).child("user_id").setValue(mAuth.getCurrentUser().getUid());
        new FcmNotification(getContext()).sendNotification(getContext(), databaseReference, mediaId, likesId, true);
        databaseReference.child(mediaId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String uid = dataSnapshot.child("userId").getValue(String.class);
                NotificationModel notificationModel = (mAuth.getCurrentUser().getUid().equals(uid))?new NotificationModel("like", "You", Long.toString(System.currentTimeMillis()),uid):new NotificationModel("like", mAuth.getCurrentUser().getDisplayName(), Long.toString(System.currentTimeMillis()),uid);
                FirebaseDatabase.getInstance().getReference("alumni_app").child("notification").child(uid).child(likesId).setValue(notificationModel);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void removeNewLike(String mediaId, String likesId) {
        databaseReference.child(mediaId).child("likes").child(likesId).removeValue();
        databaseReference.child(mediaId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String uid = dataSnapshot.child("userId").getValue(String.class);
                FirebaseDatabase.getInstance().getReference("alumni_app").child("notification").child(uid).child(likesId).removeValue();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        CircleImageView profilePic;
        TextView name;
        TextView timestamp;
        TextView caption;
        TextView textUrl;
        ImageView feedImage;
        ImageView heartOutline;
        ImageView heartRed;
        ImageView comment;
        TextView viewComments;
        TextView likedBy;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            profilePic = itemView.findViewById(R.id.profilePic);
            name = itemView.findViewById(R.id.name);
            timestamp = itemView.findViewById(R.id.timestamp);
            caption = itemView.findViewById(R.id.txtStatusMsg);
            textUrl = itemView.findViewById(R.id.txtUrl);
            feedImage = itemView.findViewById(R.id.feedImage1);
            likedBy = itemView.findViewById(R.id.like_number);
            heartOutline = itemView.findViewById(R.id.heart_outline);
            heartRed = itemView.findViewById(R.id.heart_red);
            comment = itemView.findViewById(R.id.comment);
            viewComments = itemView.findViewById(R.id.view_comments);
        }
    }
}
